/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sumtennumbers;

/**
 *
 * @author SCC
 */
public class SumTenNumbers {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
   int sum=0;
        for(int i=0; i<=10; i++){
             sum+=i;
        }
        System.out.println("sum ten numbers = " +sum);
        //System.out.print("sum of the first ten positive integers: ");
	//System.out.println(1+ 2 +3 + 4 + 5 + 6 + 7 + 8 + 9 + 10);
    }
    
}
