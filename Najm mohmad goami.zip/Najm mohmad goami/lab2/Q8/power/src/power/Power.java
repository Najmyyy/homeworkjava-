

package power;

import java.util.Scanner;

public class Power {

    
    
    public static void main(String[] args) {
      
        double val =2;
        System.out.printf("Square: %12.2f\n", val * val);
        System.out.printf("Cube: %14.2f\n", val * val * val);
        System.out.printf("Fourth power: %6.2f\n", Math.pow(val, 4));
        
    }
    
}
